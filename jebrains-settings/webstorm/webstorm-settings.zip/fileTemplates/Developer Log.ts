//
//  Logs for ${DATE}
//  ${NAME}.ts
//
//  Created by d-exclaimation on ${TIME}.
//  Copyright © ${YEAR} d-exclaimation. All rights reserved.
//

const logs = (): void => {
    let note: string = `
       <LOG> 
    `
    console.log(note);
}

logs()