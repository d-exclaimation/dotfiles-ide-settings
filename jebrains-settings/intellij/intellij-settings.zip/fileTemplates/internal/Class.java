//
//  ${NAME}.java
//  ${PROJECT_NAME}
//
//  Created by d-exclaimation on ${TIME}.
//  Copyright © ${YEAR} d-exclaimation. All rights reserved.
//
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
public class ${NAME} {
}
