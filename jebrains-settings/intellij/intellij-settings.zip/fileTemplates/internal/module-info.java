//
//  ${NAME}.java
//  ${PROJECT_NAME}
//
//  Created by d-exclaimation on ${TIME}.
//  Copyright © ${YEAR} d-exclaimation. All rights reserved.
//
#parse("File Header.java")
module #[[$MODULE_NAME$]]# {
}