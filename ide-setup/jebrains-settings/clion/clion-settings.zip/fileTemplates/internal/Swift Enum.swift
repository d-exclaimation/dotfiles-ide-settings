//
//  ${NAME}.swift
//  ${PROJECT_NAME}
//
//  Created by d-exclaimation on ${TIME}.
//  Copyright © ${YEAR} d-exclaimation. All rights reserved.
//

import Foundation

enum ${NAME} {
}
