#
#  ${NAME}.ex
#  ${PACKAGE_NAME}
#
#  Created by d-exclaimation on ${TIME}.
#  Copyright © ${YEAR} d-exclaimation. All rights reserved.
#

defmodule ${NAME} do
#parse("Elixir File Docs.ex")
  use Application

  def start(_type, _args) do
    ${NAME}.Supervisor.start_link()
  end
end