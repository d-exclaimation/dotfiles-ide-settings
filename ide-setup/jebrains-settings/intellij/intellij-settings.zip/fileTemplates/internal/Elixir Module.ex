#
#  ${NAME}.ex
#  ${PACKAGE_NAME}
#
#  Created by d-exclaimation on ${TIME}.
#  Copyright © ${YEAR} d-exclaimation. All rights reserved.
#

defmodule ${NAME} do
end
