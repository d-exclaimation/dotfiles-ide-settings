//
//  ${NAME}.ts
//  ${PROJECT_NAME}
//
//  Created by d-exclaimation on ${TIME}.
//  Copyright © ${YEAR} d-exclaimation. All rights reserved.
//
