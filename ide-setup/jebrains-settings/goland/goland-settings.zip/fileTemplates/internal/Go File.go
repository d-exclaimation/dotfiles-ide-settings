//
//  ${NAME}.go
//  ${GO_PACKAGE_NAME}
//
//  Created by d-exclaimation on ${TIME}.
//  Copyright © 2021 d-exclaimation. All rights reserved.
//

package ${GO_PACKAGE_NAME}
