//
//  ${NAME}.rust
//  ${PROJECT_NAME}
//
//  Created by d-exclaimation on ${TIME}.
//  Copyright © 2021 d-exclaimation. All rights reserved.
//
